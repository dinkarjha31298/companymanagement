﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagement.Data;
using CompanyManagement.Models;
using System.Net;
using CompanyManagement.Repository;
using CompanyManagement.Manager;

namespace CompanyManagement.Controllers
{
    [Route("api/v1.0/market/[controller]/[action]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        readonly log4net.ILog _log4net;
        private readonly CompanyManager companyManager;
        public CompanyController(CompanyManager _companyManager)
        {
            companyManager = _companyManager;
            _log4net = log4net.LogManager.GetLogger(typeof(CompanyController));
        }

        // GET: api/v1.0/market/companies
        /// <summary>
        /// Get method called by api
        /// In the Get method,object of Manager is calling getCompanies method and check about the CompanyList 
        /// </summary>
        /// <returns>return List of companies to Api</returns>
        [HttpGet]
        public IActionResult getAll()
        {

            _log4net.Info("CompanyController  Action Method called");
            try
            {
                _log4net.Info("CompanyManager's getCompanies is calling for " + nameof(CompanyController));
                var obj = companyManager.getCompanies();
                if(obj==null)
                {
                    _log4net.Error("Database is empty for" + nameof(CompanyController));
                    return NoContent();
                }
                _log4net.Info("BaseRepo's get works for " + nameof(CompanyRepo));
                _log4net.Info("CompanyRepo's getCompaniesRepo works for " + nameof(CompanyManager));
                _log4net.Info("CompanyManager's getCompanies works for " + nameof(CompanyController));
                return Ok(obj);
            }
            catch (Exception e)
            {
                _log4net.Error(nameof(CompanyController) + "'s exception is" + e.Message);
                return BadRequest(e);//isv
            }
        }
        /// <summary>
        /// Get method called by api
        /// In the info method,object of Manager is calling getCompany method with id and check about the Company 
        /// </summary>
        /// <returns>return List of company to Api</returns>
        // GET: api/v1.0/market/companies/info/5
        [HttpGet("{id}")]
        public IActionResult info(int id)
        {
            _log4net.Info("CompanyController  Action Method called");
            try
            {
                _log4net.Info("CompanyManager's getCompany is calling for " + nameof(CompanyController));
                var obj = companyManager.getCompany(id);
                if (obj == null)
                {
                    _log4net.Error("Not a company with this id for" + nameof(CompanyController));
                    return NoContent();
                }
                _log4net.Info("BaseRepo's getById works for " + nameof(CompanyRepo));
                _log4net.Info("CompanyRepo's getCompanyRepo works for " + nameof(CompanyManager));
                _log4net.Info("CompanyManager's getCompany works for " + nameof(CompanyController));
                return Ok(obj);
            }
            catch (Exception e)
            {
                _log4net.Error(nameof(CompanyController) + "'s exception is" + e.Message);
                return BadRequest();
            }
        }

        /// <summary>
        /// Post method called by api
        /// In the register method,object of Manager is calling addCompany method and update to database 
        /// </summary>
        /// <returns>return a message of successfull registration of company to Api</returns>
        // POST: api/v1.0/market/Companies/register
        [HttpPost]
        public IActionResult register([FromBody] Company company)
        {
            _log4net.Info("CompanyController  Action Method called");
            _log4net.Info("CompanyController's  ModelState is validating");
            if (ModelState.IsValid)
            {
                _log4net.Info("CompanyController's ModelState is Valid");
                try
                {
                    _log4net.Info("CompanyManager's addCompany is calling for " + nameof(CompanyController));
                    int result = companyManager.addCompany(company);
                    if (result != 1)
                    {
                        _log4net.Error("It is a BadRequest for" + nameof(CompanyController));
                        return BadRequest();
                    }
                    _log4net.Info("BaseRepo's add works for " + nameof(CompanyRepo));
                    _log4net.Info("CompanyRepo's addCompanyRepo works for " + nameof(CompanyManager));
                    _log4net.Info("CompanyManager's addCompany works for " + nameof(CompanyController));
                    return Ok("successfully registered");

                }
                catch (Exception e)
                {
                    _log4net.Error(nameof(CompanyController) + "'s exception is" + e.Message);
                    return BadRequest("Exception occurs");
                }
            }
            _log4net.Info("CompanyController's ModelState is unvalid");
            return BadRequest();
        }
        /// <summary>
        /// Delete method called by api
        /// In the delete method,object of Manager is calling deletecompany with id method and expecting 1 for successful delete
        /// </summary>
        /// <returns>return a message of successful deletion to Api</returns>
        // DELETE: api/v1.0/market/Companies/delete/5
        [HttpDelete("{id}")]
        public IActionResult delete(int id)
        {
            _log4net.Info("CompanyController  Action Method called");
            try
            {
                _log4net.Info("CompanyManager's deleteCompany is calling for " + nameof(CompanyController));
                int result = companyManager.deleteCompany(id);
                if (result!= 1)
                {
                    _log4net.Error("Not a company with this id" + nameof(CompanyController));
                    return NoContent();
                }
                _log4net.Info("BaseRepo's delete works for " + nameof(CompanyRepo));
                _log4net.Info("CompanyRepo's deleteCompanyRepo works for " + nameof(CompanyManager));
                _log4net.Info("CompanyManager's deleteCompany works for " + nameof(CompanyController));
                return Ok("succesfully deleted");
            }
            catch (Exception e)
            {
                _log4net.Error(nameof(CompanyController) + "'s exception is" + e.Message);
                return BadRequest("Exception occurs");
            }
        }
    }
}
