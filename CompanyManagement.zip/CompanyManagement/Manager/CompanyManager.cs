﻿using CompanyManagement.Models;
using CompanyManagement.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyManagement.Manager
{
    public class CompanyManager
    {
        readonly log4net.ILog _log4net;
        public ICompanyRepo iCompanyRepo;
        public CompanyManager(ICompanyRepo _iCompanyRepo)
        {
            _log4net = log4net.LogManager.GetLogger(typeof(CompanyManager));
            iCompanyRepo = _iCompanyRepo;
        }
        /// <summary>
        /// getCompanies method called by controller
        /// In the getCompanies method,object of IComapnyRepo is calling getCompaniesRepo method and check about the CompanyList 
        /// </summary>
        /// <returns> expecting List of companies to Controller</returns>
        public List<Company> getCompanies()
        {
            _log4net.Info("CompanyManager getCompanies Method called");
            try
            {
                _log4net.Info("CompanyRepo's getCompaniesRepo is calling for " + nameof(CompanyManager));
                var obj = iCompanyRepo.getCompaniesRepo();
                if(obj==null)
                {
                    _log4net.Error("Database is empty for " + nameof(CompanyManager));
                    return null;
                }
                _log4net.Info("BaseRepo's get works for " + nameof(CompanyRepo));
                _log4net.Info("CompanyRepo's getCompaniesRepo works for " + nameof(CompanyManager));
                return obj ;
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyManager) + "'s exception is" + e.Message);
                throw e;
            }
        }
        /// <summary>
        /// getCompany method called by controller
        /// In the getCompany method,object of IComapnyRepo is calling getCompanyRepo method with id and check about the Company that is registered with the id
        /// </summary>
        /// <returns>expecting Company details to Controller</returns>
        public Company getCompany(int id)
        {
            _log4net.Info("CompanyManager getCompany Method called");
            try 
            {
                _log4net.Info("CompanyRepo's getCompanyRepo is calling for " + nameof(CompanyManager));
                var company = iCompanyRepo.getCompanyRepo(id);
                if (company == null)
                {
                    _log4net.Error("there is not any registered company with this id " + nameof(CompanyManager));
                    return company;
                }
                _log4net.Info("BaseRepo's getById works for " + nameof(CompanyRepo));
                _log4net.Info("CompanyRepo's getCompanyRepo works for " + nameof(CompanyManager));
                return company;
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyManager) + "'s exception is" + e.Message);
                throw e;
            }

        }
        /// <summary>
        /// addCompany method called by controller
        /// In the addCompany method,object of IComapnyRepo is calling addCompanyRepo method and register the new company in database 
        /// </summary>
        /// <returns>expecting anything except null for succesfull registration to Controller</returns>
        public int addCompany(Company comp)
        {
            _log4net.Info("CompanyManager addCompany Method called");
            try 
            {
                _log4net.Info("CompanyRepo's addCompanyRepo is calling for " + nameof(CompanyManager));
                var s=iCompanyRepo.addCompanyRepo(comp);
                if(s!=1)
                {
                    _log4net.Error("It is a BadRequest for " + nameof(CompanyManager));
                    return 0;
                }
                _log4net.Info("BaseRepo's add works for " + nameof(CompanyRepo));
                _log4net.Info("CompanyRepo's addCompanyRepo works for " + nameof(CompanyManager));
                return s;
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyManager) + "'s exception is" + e.Message);
                throw e;
            }
        }
        /// <summary>
        /// deleteCompany method called by controller
        /// In the addCompany method,object of IComapnyRepo is calling deleteCompanyRepo method with id and delete the company from database 
        /// </summary>
        /// <returns> expecting anything except null for succesfull deletion to Controller</returns>
        public int deleteCompany(int id)
        {
            _log4net.Info("CompanyManager deleteCompanies Method called");
            try
            {
                _log4net.Info("CompanyRepo's deleteCompaniesRepo is calling for " + nameof(CompanyManager));
                var company = iCompanyRepo.getCompanyRepo(id);
                if (company != null)
                {
                    _log4net.Info("BaseRepo's delete works for " + nameof(CompanyRepo));
                    _log4net.Info("CompanyRepo's deleteCompanyRepo works for " + nameof(CompanyManager));
                    var s = iCompanyRepo.deleteCompanyRepo(id);
                    return s;
                }
                else
                {
                    _log4net.Error("there is not any registered company with this id  " + nameof(CompanyManager));
                    return 0;
                    
                }
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyManager) + "'s exception is" + e.Message);
                throw e;
            }
        }
    }
}

