﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CompanyManagement.Migrations
{
    public partial class companyadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Company",
                columns: table => new
                {
                    companyCode = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    companyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    companyCEO = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    companyTurnover = table.Column<int>(type: "int", nullable: false),
                    companyWebsite = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    companyStockexchange = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.companyCode);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Company");
        }
    }
}
