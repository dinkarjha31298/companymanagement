﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagement.Models
{
    public class Company:BaseEntity
    {
        [Key]
        public int companyCode { get; set; }
        [Required(ErrorMessage = "Value must be filled")]
        public string companyName { get; set; }
        [Required(ErrorMessage = "Value must be filled")]
        public string companyCEO { get; set; }
        [Required(ErrorMessage = "Value must be filled")]
        [Range(100000000,int.MaxValue,ErrorMessage ="Value must be greater than 10cr")]
        public int companyTurnover { get; set; }
        [Required(ErrorMessage ="Value must be filled")]
        [Url(ErrorMessage = "it should be in url pattern,e.g.-https://example.com")]
        public string companyWebsite { get; set; }
        [Required(ErrorMessage = "Value must be filled")]
        public string companyStockexchange { get; set; }
    }
}
