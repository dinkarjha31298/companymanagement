﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CompanyManagement.Models;

namespace CompanyManagement.Data
{
    public class CompanyManagementDbContext : DbContext
    {
        public CompanyManagementDbContext (DbContextOptions<CompanyManagementDbContext> options)
            : base(options)
        {
        }

        public DbSet<Company> Company { get; set; }
    }
}
