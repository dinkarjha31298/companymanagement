﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CompanyManagement.Models;

namespace CompanyManagement.Repository
{
    public interface IBaseRepo<T> where T:BaseEntity
    {
        public List<T> get();
        public T getById(int id);
        public int add(T obj);
        public int delete(int id);
    }
}
