﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using CompanyManagement.Data;
using CompanyManagement.Models;

namespace CompanyManagement.Repository
{
    public class BaseRepo<T> : IBaseRepo<T> where T:BaseEntity
    {
        private readonly CompanyManagementDbContext context;
        private DbSet<T> entities;
        public BaseRepo(CompanyManagementDbContext _context)
        {
            this.context = _context;
            entities = _context.Set<T>();
        }
        public List<T> get()
        {
            return entities.ToList();
        }

        public T getById(int id)
        {
            return entities.Find(id);
        }

        public int add(T obj)
        {
            try
            {
                if (obj != null)
                {
                    entities.Add(obj);
                    context.SaveChanges();
                    return 1;
                }
                else
                    throw new ArgumentNullException("entity");
            }
            catch(Exception e)
            {
                throw e;
            }

        }

        public int delete(int id)
        {
            try
            {
                if (id != null)
                {
                    T entity = entities.Find(id);
                    entities.Remove(entity);
                    context.SaveChanges();
                    return 1;
                }
                else
                    throw new NotImplementedException();
            }
            catch(Exception e)
            {
                throw e;
            }
        }
    }
}
