﻿using CompanyManagement.Data;
using CompanyManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyManagement.Repository
{
    public class CompanyRepo:ICompanyRepo
    {
        readonly log4net.ILog _log4net;
        private readonly IBaseRepo<Company> baseRepo;
        public CompanyRepo(IBaseRepo<Company> _baseRepo)
        {
            this.baseRepo = _baseRepo;
            _log4net = log4net.LogManager.GetLogger(typeof(CompanyRepo));
        }

        /// <summary>
        /// getCompaniesRepo method called by CompanyManager
        /// In the getCompaniesRepo method,object of IBaseRepo is calling get method and check about the List from DataBase
        /// </summary>
        /// <returns> expecting List of companies to CompanyManager</returns>
        public List<Company> getCompaniesRepo()
        {
            _log4net.Info("CompanyRepo getCompaniesRepo Method called");
            try
            {
                var obj = baseRepo.get();
                if(obj==null)
                {
                    _log4net.Error("Database is empty for " + nameof(CompanyRepo));
                    return null;
                }
                _log4net.Info("BaseRepo's get works for " + nameof(CompanyRepo));
                return obj;
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyRepo) + "'s exception is" + e.Message);
                throw e;
            }
        }

        /// <summary>
        /// getById method called by CompanyManager
        /// In the getCompanyRepo method,object of IBaseRepo is calling getById method with id and check about the Company that is registered with the id
        /// </summary>
        /// <returns>expecting Company details to CompanyManager</returns>
        public Company getCompanyRepo(int id)
        {
            _log4net.Info("CompanyRepo getCompanyRepo Method called");
            try
            {
                _log4net.Info("BaseRepo's getById is calling for " + nameof(CompanyRepo));
                var company = baseRepo.getById(id);
                if (company != null)
                {
                    
                    _log4net.Info("BaseRepo's getById works for " + nameof(CompanyRepo));
                    return (company);
                }
                _log4net.Error("there is not any registered company with this id " + nameof(CompanyRepo));
                return null;
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyRepo) + "'s exception is" + e.Message);
                throw e;
            }

        }

        /// <summary>
        /// add method called by CommpanyManager
        /// In the addComponyRepo method,object of IBaseRepo is calling add method with id and add the all details of company in the database
        /// </summary>
        /// <returns>expecting CompanyCode for successfull addition to ComponyManager for successful</returns>
        public int addCompanyRepo(Company comp)
        {
            _log4net.Info("CompanyRepo's addCompanyRepo Method called");
            try
            {
                _log4net.Info("BaseRepo's add is calling for " + nameof(CompanyRepo));
                var obj=baseRepo.add(comp);
                if (obj != 1)
                {
                    _log4net.Error("BadRequests for " + nameof(CompanyRepo));
                    return 0;
                }
                _log4net.Info("BaseRepo's add works for " + nameof(CompanyRepo));
                return obj;
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyRepo) + "'s exception is" + e.Message);
                throw e;
            }
        }

        /// <summary>
        /// delete method called by CommpanyManager
        /// In the deleteCompanyRepo method,object of IBaseRepo is calling delete method with id and add the all details of company in the database
        /// </summary>
        /// <returns>expecting integer 1 for successfull deletion to ComponyManager</returns>
        public int deleteCompanyRepo(int id)
        {
            _log4net.Info("CompanyRepo deleteCompany Method called");
            try
            {
                _log4net.Info("BaseRepo's delete is calling for " + nameof(CompanyRepo));
                var company = baseRepo.getById(id);
                if (company != null)
                {
                    _log4net.Info("BaseRepo's delete works for " + nameof(CompanyRepo));
                    var obj = baseRepo.delete(id);
                    return obj;
                }
                else
                {
                    _log4net.Error("BadRequest for " + nameof(CompanyRepo));
                    return 0;
                }
            }
            catch(Exception e)
            {
                _log4net.Error(nameof(CompanyRepo) + "'s exception is" + e.Message);
                throw e;
            }
        }
    }
}
