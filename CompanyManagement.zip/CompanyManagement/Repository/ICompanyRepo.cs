﻿using CompanyManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyManagement.Repository
{
    public interface ICompanyRepo
    {
        public List<Company> getCompaniesRepo();
        public Company getCompanyRepo(int id);
        public int addCompanyRepo(Company comp);
        public int deleteCompanyRepo(int id);
    }
}
